module.exports=[94466,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reservation_page_actions_1f0e09f.js.map