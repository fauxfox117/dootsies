globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/VI6JDtwmqHqUHylHGpZDY/_buildManifest.js",
    "static/VI6JDtwmqHqUHylHGpZDY/_ssgManifest.js",
    "static/VI6JDtwmqHqUHylHGpZDY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1bdphy994af6q.js",
    "static/chunks/1uhg63a4xulss.js",
    "static/chunks/1j_9b-l0n6u-t.js",
    "static/chunks/turbopack-1g89ularvn3ik.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
